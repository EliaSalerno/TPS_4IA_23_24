import paho.mqtt.publish as publish
import time
TOPIC="prova1"
#BROKER="test.mosquitto.org"
BROKER="192.168.43.47"

# pubblica ad intervalli di 5 secondi un numero progressivo
i=0
while True:
    i=i+1
    msg=str(i)
    print(i)
    
    publish.single(TOPIC, msg, hostname=BROKER)
    
    time.sleep(5)